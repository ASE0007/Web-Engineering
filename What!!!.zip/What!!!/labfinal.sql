-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2025 at 06:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `labfinal`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `profileCreatedBy` varchar(50) NOT NULL,
  `lookingFor` varchar(20) NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `nationality` varchar(100) DEFAULT NULL,
  `caste` varchar(100) DEFAULT NULL,
  `presentRegion` varchar(100) DEFAULT NULL,
  `maritalStatus` varchar(30) NOT NULL,
  `dateOfBirth` date NOT NULL,
  `education` varchar(100) DEFAULT NULL,
  `profession` varchar(100) DEFAULT NULL,
  `presentCountry` varchar(100) NOT NULL,
  `presentDivision` varchar(100) NOT NULL,
  `presentDistrict` varchar(100) NOT NULL,
  `presentUpazila` varchar(100) NOT NULL,
  `village` varchar(100) DEFAULT NULL,
  `landmark` varchar(255) DEFAULT NULL,
  `residencyStatus` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `confirmEmail` varchar(200) DEFAULT NULL,
  `candidatePhone` varchar(20) NOT NULL,
  `guardianPhone` varchar(20) DEFAULT NULL,
  `passwordHash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `profileCreatedBy`, `lookingFor`, `firstName`, `lastName`, `nationality`, `caste`, `presentRegion`, `maritalStatus`, `dateOfBirth`, `education`, `profession`, `presentCountry`, `presentDivision`, `presentDistrict`, `presentUpazila`, `village`, `landmark`, `residencyStatus`, `email`, `confirmEmail`, `candidatePhone`, `guardianPhone`, `passwordHash`, `created_at`, `updated_at`) VALUES
(1, 'self', 'bride', 'abid', 'esti', 'bangla', 'mirpur', 'asdasd', 'unmarried', '2003-05-05', 'graduate', 'doctor', 'bangladesh', 'dhaka', 'dhaka', 'ঢাকা', '', '', 'citizen', 'abid@gmail.com', 'abid@gmail.com', '01727590390', '01727590390', '$2y$10$8I88LXZcfb6nqGgmXlUI2O0Smzgbyg22jDL5Iax0PcD.bhegPbTkW', '2025-08-16 16:00:27', '2025-08-16 16:00:27');

-- --------------------------------------------------------

--
-- Table structure for table `user_sessions`
--

CREATE TABLE `user_sessions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `session_token` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_in` int(11) DEFAULT 3600
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `candidatePhone` (`candidatePhone`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_phone` (`candidatePhone`);

--
-- Indexes for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_sessions`
--
ALTER TABLE `user_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD CONSTRAINT `user_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
