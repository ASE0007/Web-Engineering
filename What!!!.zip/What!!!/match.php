<?php
$servername = "localhost";
$username = "root";
$password = "";  // your DB password
$dbname = "labfinal";  // your DB name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session to manage login state
session_start();

// Helper function to sanitize input
function sanitize($data) {
    global $conn;
    return htmlspecialchars($conn->real_escape_string(trim($data)));
}

// Detect if this is a login or registration request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        if ($action === 'register') {
            // Registration logic
            $profileCreatedBy = sanitize($_POST['profileCreatedBy'] ?? '');
            $lookingFor = sanitize($_POST['lookingFor'] ?? '');
            $firstName = sanitize($_POST['firstName'] ?? '');
            $lastName = sanitize($_POST['lastName'] ?? '');
            $dateOfBirth = sanitize($_POST['dateOfBirth'] ?? '');
            $maritalStatus = sanitize($_POST['maritalStatus'] ?? '');
            $email = sanitize($_POST['email'] ?? '');
            $confirmEmail = sanitize($_POST['confirmEmail'] ?? '');
            $candidatePhone = sanitize($_POST['candidatePhone'] ?? '');
            $password = $_POST['password'] ?? '';
            $confirmPassword = $_POST['confirmPassword'] ?? '';
            $termsAgreement = isset($_POST['termsAgreement']) ? true : false;

            // Validate inputs (server side)
            $errors = [];
            if (empty($profileCreatedBy)) $errors[] = 'Profile Created By is required';
            if (empty($lookingFor)) $errors[] = 'Looking For is required';
            if (empty($firstName)) $errors[] = 'First Name is required';
            if (empty($lastName)) $errors[] = 'Last Name is required';
            if (empty($dateOfBirth)) $errors[] = 'Date of Birth is required';
            if (empty($maritalStatus)) $errors[] = 'Marital Status is required';
            if (empty($email)) $errors[] = 'Email is required';
            if ($email !== $confirmEmail) $errors[] = 'Emails do not match';
            if (empty($candidatePhone)) $errors[] = 'Phone number is required';
            if (empty($password)) $errors[] = 'Password is required';
            if ($password !== $confirmPassword) $errors[] = 'Passwords do not match';
            if (!$termsAgreement) $errors[] = 'You must agree to terms';

            if (count($errors) > 0) {
                echo json_encode(['status' => 'error', 'errors' => $errors]);
                exit;
            }

            // Check if email or phone already exists
            $stmt = $conn->prepare('SELECT id FROM users WHERE email = ? OR candidatePhone = ?');
            $stmt->bind_param('ss', $email, $candidatePhone);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) {
                echo json_encode(['status' => 'error', 'errors' => ['Email or Phone Number already registered']]);
                exit;
            }
            $stmt->close();

            // Hash password
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);

            // Insert user into database
            $stmt = $conn->prepare('INSERT INTO users (profileCreatedBy, lookingFor, firstName, lastName, dateOfBirth, maritalStatus, email, candidatePhone, passwordHash) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->bind_param('sssssssss', $profileCreatedBy, $lookingFor, $firstName, $lastName, $dateOfBirth, $maritalStatus, $email, $candidatePhone, $passwordHash);

            if ($stmt->execute()) {
                echo json_encode(['status' => 'success', 'message' => 'Registration successful']);
            } else {
                echo json_encode(['status' => 'error', 'errors' => ['Database error: ' . $conn->error]]);
            }
            $stmt->close();
            exit;

        } elseif ($action === 'login') {
            // Login logic
            $emailOrProfile = sanitize($_POST['emailOrProfile'] ?? '');
            $password = $_POST['password'] ?? '';

            if (empty($emailOrProfile) || empty($password)) {
                echo json_encode(['status' => 'error', 'errors' => ['Email/Profile and password are required']]);
                exit;
            }

            $stmt = $conn->prepare('SELECT id, firstName, lastName, passwordHash FROM users WHERE email = ? OR candidatePhone = ? LIMIT 1');
            $stmt->bind_param('ss', $emailOrProfile, $emailOrProfile);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows === 1) {
                $stmt->bind_result($userId, $firstName, $lastName, $passwordHash);
                $stmt->fetch();
                if (password_verify($password, $passwordHash)) {
                    // Login successful
                    $_SESSION['user_id'] = $userId;
                    $_SESSION['user_name'] = $firstName . ' ' . $lastName;
                    echo json_encode(['status' => 'success', 'redirect' => 'dashboard.html']);
                } else {
                    echo json_encode(['status' => 'error', 'errors' => ['Incorrect password']]);
                }
            } else {
                echo json_encode(['status' => 'error', 'errors' => ['User not found']]);
            }
            $stmt->close();
            exit;
        }
    }
}

// Close connection
$conn->close();
?>
