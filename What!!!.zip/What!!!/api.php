<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "labfinal";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Database connection failed']));
}

// Helper function to sanitize input
function sanitize($data) {
    global $conn;
    return htmlspecialchars($conn->real_escape_string(trim($data)));
}

// Handle POST requests (Registration and Login)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'register') {
        // Collect and sanitize ALL registration inputs
        $profileCreatedBy = sanitize($_POST['profileCreatedBy'] ?? '');
        $lookingFor = sanitize($_POST['lookingFor'] ?? '');
        $firstName = sanitize($_POST['firstName'] ?? '');
        $lastName = sanitize($_POST['lastName'] ?? '');
        $nationality = sanitize($_POST['nationality'] ?? '');
        $caste = sanitize($_POST['caste'] ?? '');
        $presentRegion = sanitize($_POST['presentRegion'] ?? '');
        $maritalStatus = sanitize($_POST['maritalStatus'] ?? '');
        $dateOfBirth = sanitize($_POST['dateOfBirth'] ?? '');
        $education = sanitize($_POST['education'] ?? '');
        $profession = sanitize($_POST['profession'] ?? '');
        $presentCountry = sanitize($_POST['presentCountry'] ?? '');
        $presentDivision = sanitize($_POST['presentDivision'] ?? '');
        $presentDistrict = sanitize($_POST['presentDistrict'] ?? '');
        $presentUpazila = sanitize($_POST['presentUpazila'] ?? '');
        $village = sanitize($_POST['village'] ?? '');
        $landmark = sanitize($_POST['landmark'] ?? '');
        $residencyStatus = sanitize($_POST['residencyStatus'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $confirmEmail = sanitize($_POST['confirmEmail'] ?? '');
        $candidatePhone = sanitize($_POST['candidatePhone'] ?? '');
        $guardianPhone = sanitize($_POST['guardianPhone'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirmPassword'] ?? '';
        $termsAgreement = isset($_POST['termsAgreement']) && $_POST['termsAgreement'] == '1';

        // Server-side validation
        $errors = [];
        if (!$profileCreatedBy) $errors[] = 'Profile Created By is required';
        if (!$lookingFor) $errors[] = 'Looking For is required';
        if (!$firstName) $errors[] = 'First Name is required';
        if (!$lastName) $errors[] = 'Last Name is required';
        if (!$maritalStatus) $errors[] = 'Marital Status is required';
        if (!$dateOfBirth) $errors[] = 'Date of Birth is required';
        if (!$presentCountry) $errors[] = 'Present Country is required';
        if (!$presentDivision) $errors[] = 'Present Division is required';
        if (!$presentDistrict) $errors[] = 'Present District is required';
        if (!$presentUpazila) $errors[] = 'Present Upazila is required';
        if (!$residencyStatus) $errors[] = 'Residency Status is required';
        if (!$email) $errors[] = 'Email is required';
        if ($email !== $confirmEmail) $errors[] = 'Emails do not match';
        if (!$candidatePhone) $errors[] = 'Phone number is required';
        if (!$password) $errors[] = 'Password is required';
        if ($password !== $confirmPassword) $errors[] = 'Passwords do not match';
        if (!$termsAgreement) $errors[] = 'You must agree to terms';

        if (count($errors) > 0) {
            echo json_encode(['status' => 'error', 'errors' => $errors]);
            exit;
        }

        // Check for existing email or phone
        $stmt = $conn->prepare('SELECT id FROM users WHERE email = ? OR candidatePhone = ?');
        $stmt->bind_param('ss', $email, $candidatePhone);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            echo json_encode(['status' => 'error', 'errors' => ['Email or Phone already registered']]);
            exit;
        }
        $stmt->close();

        // Hash password
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        // Insert all user data into database
        $stmt = $conn->prepare("
            INSERT INTO users (
                profileCreatedBy, lookingFor, firstName, lastName, nationality, caste, 
                presentRegion, maritalStatus, dateOfBirth, education, profession, 
                presentCountry, presentDivision, presentDistrict, presentUpazila, 
                village, landmark, residencyStatus, email, confirmEmail, 
                candidatePhone, guardianPhone, passwordHash
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->bind_param(
            'sssssssssssssssssssssss', 
            $profileCreatedBy, $lookingFor, $firstName, $lastName, $nationality, $caste,
            $presentRegion, $maritalStatus, $dateOfBirth, $education, $profession,
            $presentCountry, $presentDivision, $presentDistrict, $presentUpazila,
            $village, $landmark, $residencyStatus, $email, $confirmEmail,
            $candidatePhone, $guardianPhone, $passwordHash
        );

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Registration successful']);
        } else {
            echo json_encode(['status' => 'error', 'errors' => ['Database error: ' . $conn->error]]);
        }
        $stmt->close();
        exit;

    } elseif ($action === 'login') {
        $emailOrProfile = sanitize($_POST['emailOrProfile'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!$emailOrProfile || !$password) {
            echo json_encode(['status' => 'error', 'errors' => ['Email/Profile and Password are required']]);
            exit;
        }

        $stmt = $conn->prepare('SELECT id, firstName, lastName, passwordHash FROM users WHERE email = ? OR candidatePhone = ? LIMIT 1');
        $stmt->bind_param('ss', $emailOrProfile, $emailOrProfile);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 1) {
            $stmt->bind_result($userId, $firstName, $lastName, $passwordHash);
            $stmt->fetch();
            
            if (password_verify($password, $passwordHash)) {
                $_SESSION['user_id'] = $userId;
                $_SESSION['user_name'] = $firstName . ' ' . $lastName;
                echo json_encode(['status' => 'success']);
            } else {
                echo json_encode(['status' => 'error', 'errors' => ['Incorrect password']]);
            }
        } else {
            echo json_encode(['status' => 'error', 'errors' => ['User not found']]);
        }
        $stmt->close();
        exit;

    } elseif ($action === 'logout') {
        session_destroy();
        if (isset($_COOKIE[session_name()])) {
            setcookie(session_name(), '', time()-42000, '/');
        }
        echo json_encode(['status' => 'success']);
        exit;
    }
}

// Handle GET requests (Dashboard Data)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
        exit;
    }

    $user_id = $_SESSION['user_id'];

    // Get complete user data
    $stmt = $conn->prepare("
        SELECT 
            id, profileCreatedBy, lookingFor, firstName, lastName, nationality, caste, 
            presentRegion, maritalStatus, dateOfBirth, education, profession, 
            presentCountry, presentDivision, presentDistrict, presentUpazila, 
            village, landmark, residencyStatus, email, candidatePhone, guardianPhone, created_at
        FROM users WHERE id = ?
    ");
    
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        // Calculate age
        $birthDate = new DateTime($user['dateOfBirth']);
        $today = new DateTime();
        $age = $today->diff($birthDate)->y;
        
        // Generate profile ID
        $profileId = 'BB' . str_pad($user['id'], 6, '0', STR_PAD_LEFT);
        
        // Generate statistics (replace with real data from additional tables if needed)
        $stats = [
            'profileViews' => rand(50, 200),
            'proposalsReceived' => rand(0, 20), 
            'proposalsSent' => rand(0, 15),
            'favorites' => rand(0, 10)
        ];

        // Prepare complete user data for dashboard
        $userData = [
            'id' => $user['id'],
            'profileId' => $profileId,
            'fullName' => $user['firstName'] . ' ' . $user['lastName'],
            'firstName' => $user['firstName'],
            'lastName' => $user['lastName'],
            'email' => $user['email'],
            'phone' => $user['candidatePhone'],
            'guardianPhone' => $user['guardianPhone'] ?: 'Not provided',
            'dateOfBirth' => $user['dateOfBirth'],
            'age' => $age,
            'maritalStatus' => ucfirst($user['maritalStatus']),
            'religion' => $user['nationality'] ?: 'Not specified',
            'caste' => $user['caste'] ?: 'Not specified',
            'education' => $user['education'] ?: 'Not specified', 
            'profession' => $user['profession'] ?: 'Not specified',
            'country' => $user['presentCountry'] ?: 'Not specified',
            'division' => $user['presentDivision'] ?: 'Not specified',
            'district' => $user['presentDistrict'] ?: 'Not specified',
            'city' => $user['presentUpazila'] ?: 'Not specified',
            'village' => $user['village'] ?: 'Not specified',
            'landmark' => $user['landmark'] ?: 'Not specified',
            'residencyStatus' => $user['residencyStatus'] ?: 'Not specified',
            'profileCreatedBy' => ucfirst($user['profileCreatedBy']),
            'lookingFor' => ucfirst($user['lookingFor']),
            'memberSince' => date('F Y', strtotime($user['created_at'])),
            'stats' => $stats
        ];

        echo json_encode(['status' => 'success', 'user' => $userData]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'User not found']);
    }
    $stmt->close();
    exit;
}

$conn->close();
?>
